﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace igrica_6
{
    public partial class Form1 : Form
    {
        List<Button> protivnici = new List<Button>();
        List<Button> meci = new List<Button>();
        List<int> pravacc= new List<int>();
        int brojtastera = 1;
        int prv=1;
        int g = 0;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {//START DUGME
            for (int i = 0; i < protivnici.Count(); i++)
            {
                Button kojitast = protivnici[i];
                kojitast.Dispose();
                protivnici.Remove(kojitast);
            }
            button3.Top = 100;
            button3.Left = 400;
            button2.PerformClick();
            button3.Enabled = true;
            button3.Focus();
            timer1.Start();
            brojtastera = 1;
            int poeni = Convert.ToInt32(label1.Text);
            poeni = 0;
            label1.Text = Convert.ToString(poeni);
        }

        private void button3_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 'a') { button3.Left -= 5;prv = 1; }
            if (e.KeyChar == 'd') { button3.Left += 5;prv = 2; }
            if (e.KeyChar == 'w') { button3.Top -= 5;prv = 3; }
            if (e.KeyChar == 's') { button3.Top += 5;prv = 4; }
            if(e.KeyChar==' ') { button4.PerformClick();
                pravacc.Insert(0, prv); }
            if(button3.Top<0)
            { button3.Top += 6; }
            if(button3.Top>300)
            { button3.Top -= 6; }
            if (button3.Left < 0)
            { button3.Left += 6; }
            if (button3.Left > 800)
            { button3.Left -= 6; }
            for (int i=0;i<protivnici.Count();i++)
            {
                Button kojitast = protivnici[i];
                if (button3.Bounds.IntersectsWith(kojitast.Bounds))
                {
                    timer1.Stop();
                    button3.Enabled = false;
                    MessageBox.Show("Game Over");
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Random r = new Random();
            for(int i=0;i<brojtastera;i++)
            {
                Button taster = new Button();
                int x = 0, y = 0;
                int poz = r.Next(1, 4);
                if(poz==1)
                {  x = r.Next(0, 45);y = r.Next(0, 45); }
                if (poz == 2)
                {  x = r.Next(200, 245);  y = r.Next(0, 45); }
                if (poz == 3)
                {  x = r.Next(0, 45);  y = r.Next(200, 245); }
                if (poz == 4)
                {  x = r.Next(200, 245);  y = r.Next(200, 245); }
                taster.BackColor = System.Drawing.Color.FromArgb(255, 0, 0);
                taster.Left = x;
                taster.Top = y;
                taster.Width = 50;
                taster.Height = 50;
                panel2.Controls.Add(taster);
                protivnici.Insert(0, taster);

            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if(g==0)
            {
                Button metak = new Button();
                metak.Left = button3.Left+20;
                metak.Top = button3.Top+20;
                metak.Width = 10;
                metak.Height = 10;
                panel2.Controls.Add(metak);
                meci.Insert(0, metak);
                g++;
            }
            
            
        }

        private void timer1_Tick(object sender, EventArgs e)
        {//KOD ZA PROTIVNIKE POMERANJE
            int i = 0;
            if(protivnici.Count()==0)
            {
                brojtastera++;
                button2.PerformClick();
            }
            if(g==1)
            {
                
                Button metak = meci[i];
                if(pravacc[i]==1)
                { metak.Left -= 10; }
                if (pravacc[i] == 2)
                { metak.Left += 10; }
                if (pravacc[i] == 3)
                { metak.Top -= 10; }
                if (pravacc[i] == 4)
                { metak.Top += 10; }
                if(metak.Top<0)
                {
                    metak.Dispose();
                    meci.Remove(metak);
                    g=0;
                }
                if (metak.Top > 300)
                {
                    metak.Dispose();
                    meci.Remove(metak);
                    g=0;
                }
                if (metak.Left < 0)
                {
                    metak.Dispose();
                    meci.Remove(metak);
                    g=0;
                }
                if (metak.Left > 800)
                {
                    metak.Dispose();
                    meci.Remove(metak);
                    g=0;
                }
                for (int j = 0; j < protivnici.Count(); j++)
                {
                    Button kojitast = protivnici[j];
                    if (metak.Bounds.IntersectsWith(kojitast.Bounds))
                    {
                        kojitast.Dispose();
                        protivnici.Remove(kojitast);
                        metak.Dispose();
                        meci.Remove(metak);
                        g=0;
                        int poeni = Convert.ToInt32(label1.Text);
                        poeni ++;
                        label1.Text = Convert.ToString(poeni);
                    }
                }
                
            }


                for (i = 0; i < protivnici.Count(); i++)
            {
                Button kojitast = protivnici[i];
                if (button3.Left>kojitast.Left)
                {
                    kojitast.Left += 3;
                }
                if (button3.Left < kojitast.Left)
                {
                    kojitast.Left -= 3;
                }
                
                if (button3.Top > kojitast.Top)
                {
                    kojitast.Top += 3;
                }
                if (button3.Top < kojitast.Top)
                {
                    kojitast.Top -= 3;
                }
            }
        }

        
        
    }
}
