﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Igrica_broj_koji_vec
{
    public partial class Form1 : Form
    {
        private int g;
        private int pravac;

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 'a') button1.Left -= 5;
            if (e.KeyChar == 'd') button1.Left += 5;
            if (e.KeyChar == 'w') button1.Top -= 5;
            if (e.KeyChar == 's') button1.Top += 5;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            timer1.Start();
            button1.Left = 40;
            button1.Top = 250;
            button1.Enabled = true;
            button1.Focus();
            button2.Left = 40;
            button2.Top = 40;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            
            
            if (button2.Left < button1.Left && g != 0)
            { button2.Left += 3; pravac = 0; }

            if (button2.Left > button1.Left && g != 1)
            { button2.Left -= 3; pravac = 1; }

            if (button2.Top < button1.Top && g != 2)
            { button2.Top += 3; pravac = 2; }

            if (button2.Top > button1.Top && g != 3)
            { button2.Top -= 3; pravac = 3; }
            if (button2.Bounds.IntersectsWith(button4.Bounds))
            {
                g = pravac;
            }
        }
    }
}
