﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Igrica1
{
    public partial class Form1 : Form
    {
        private int old_y;
        private int old_x;
        private int nesto;
        private int nesto2;

        public Form1()
        {
            InitializeComponent();
            
        }

        private void button1_KeyPress(object sender, KeyPressEventArgs e)
        {
            

            if (e.KeyChar == 'a') button1.Left -= 5;
            if (e.KeyChar == 'd') button1.Left += 5;
            if (e.KeyChar == 'w') button1.Top -= 5;
            if (e.KeyChar == 's') button1.Top += 5;

            if (button1.Top < 50) button1.Top = 55;
            if (button1.Top > 460) button1.Top = 455;
            if (button1.Left < 0) button1.Left = 0;
            if (button1.Left > 660) button1.Left = 655;

            if(button1.Bounds.IntersectsWith(button4.Bounds)|| button1.Bounds.IntersectsWith(button7.Bounds))
            {
                button1.Left = old_x;
                button1.Top = old_y;
            }
            else
            {
                old_x = button1.Left;
                old_y = button1.Top;
            }


            
        }

        private void button2_Click (object sender, EventArgs e)
        {
            Random broj = new Random();
            int x = broj.Next(0, 660);
            int y = broj.Next(50, 470);
            if(button1.Bounds.IntersectsWith(button2.Bounds)|| button2.Bounds.IntersectsWith(button3.Bounds)|| button2.Bounds.IntersectsWith(button4.Bounds))
            {
                button2.Left = x;
                button2.Top = y;
                int poeni = Convert.ToInt32(label2.Text);
                poeni++;
                label2.Text = Convert.ToString(poeni);
            }
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Random broj = new Random();
            int x = broj.Next(0, 640);
            int y = broj.Next(55, 440);
            if (button1.Bounds.IntersectsWith(button3.Bounds) || button3.Bounds.IntersectsWith(button2.Bounds) || button3.Bounds.IntersectsWith(button4.Bounds))
            {
                button2.Left = x;
                button2.Top = y;
                int poeni = Convert.ToInt32(label2.Text);
                poeni--;
                label2.Text = Convert.ToString(poeni);
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            button1.Enabled = true;
            button1.Top = 151;
            button1.Left = 314;
            timer1.Start();
            timer2.Start();
            label1.Text = "30";
            label2.Text = "0";
            button1.Focus();
            button8.Top = 50;
            button9.Top = 373;
            nesto = 0;
            nesto2 = 1;
            Random broj = new Random();
            int x = broj.Next(0, 660);
            int y = broj.Next(50, 470);
            button5.Top = y;
            button5.Left = x;
            button10.Top = 399;
            button10.Left = 645;
            x = broj.Next(0, 660);
            y = broj.Next(50, 470);
            button3.Top = y;
            button3.Left = x;
            x = broj.Next(0, 660);
            y = broj.Next(50, 470);
            button2.Top = y;
            button2.Left = x;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            int vreme = Convert.ToInt32(label1.Text);
            vreme--;
            label1.Text = Convert.ToString(vreme);
            if (vreme == 0)
            {
                timer1.Stop();
                timer2.Stop();
                button1.Enabled = false;
                MessageBox.Show("GAME OVER");
            }
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            
            
            if(button8.Top>373||nesto==1)
            {
                    button8.Top -= 10;
                nesto = 1;
                    if (button8.Bounds.IntersectsWith(button1.Bounds))
                    {
                        timer1.Stop();
                        timer2.Stop();
                        button1.Enabled = false;
                        MessageBox.Show("Game over!");
                    }
                if (button8.Top < 50)
                    nesto = 0;
            }
            else if(nesto==0)
            {
                button8.Top += 10;
                if (button8.Bounds.IntersectsWith(button1.Bounds))
                {
                    timer1.Stop();
                    timer2.Stop();
                    button1.Enabled = false;
                    MessageBox.Show("Game over!");
                }
            }

            if (button9.Top > 373 || nesto2 == 1)
            {
                button9.Top -= 10;
                nesto2 = 1;
                if (button9.Bounds.IntersectsWith(button1.Bounds))
                {
                    timer1.Stop();
                    timer2.Stop();
                    button1.Enabled = false;
                    MessageBox.Show("Game over!");
                }
                if (button9.Top < 50)
                    nesto2 = 0;
            }
            else if (nesto2 == 0)
            {
                button9.Top += 10;
                if (button9.Bounds.IntersectsWith(button1.Bounds))
                {
                    timer1.Stop();
                    timer2.Stop();
                    button1.Enabled = false;
                    MessageBox.Show("Game over!");
                }
            }



            if(button10.Left < button1.Left)
            {
                button10.Left += 4;
            }
            if (button10.Left > button1.Left)
            {
                button10.Left -= 4;
            }
            if (button10.Top < button1.Top)
            {
                button10.Top += 4;
            }
            if(button10.Top > button1.Top)
            {
                button10.Top -= 4;
            }
            if (button10.Bounds.IntersectsWith(button1.Bounds))
            {
                timer1.Stop();
                timer2.Stop();
                button1.Enabled = false;
                MessageBox.Show("Game over!");
            }

            Random broj = new Random();
            int x = broj.Next(0, 660);
            int y = broj.Next(50, 470);
            if (button1.Bounds.IntersectsWith(button2.Bounds))
            {
                button2.Left = x;
                button2.Top = y;
                int poeni = Convert.ToInt32(label2.Text);
                poeni++;
                label2.Text = Convert.ToString(poeni);
            }

            if (button2.Bounds.IntersectsWith(button3.Bounds) || button2.Bounds.IntersectsWith(button4.Bounds) || button2.Bounds.IntersectsWith(button7.Bounds))
            {
                button2.Left = x;
                button2.Top = y;
            }

            if (button1.Bounds.IntersectsWith(button5.Bounds))
            {
                button5.Left = x;
                button5.Top = y;
                int poeni = Convert.ToInt32(label2.Text);
                poeni++;
                label2.Text = Convert.ToString(poeni);
            }

            if (button5.Bounds.IntersectsWith(button3.Bounds) || button5.Bounds.IntersectsWith(button4.Bounds) || button5.Bounds.IntersectsWith(button7.Bounds))
            {
                button5.Left = x;
                button5.Top = y;
            }

            if (button1.Bounds.IntersectsWith(button3.Bounds))
            {
                x = broj.Next(0, 620);
                y = broj.Next(50, 420);
                button3.Left = x;
                button3.Top = y;
                int poeni = Convert.ToInt32(label2.Text);
                poeni--;
                label2.Text = Convert.ToString(poeni);
            }
            if (button3.Bounds.IntersectsWith(button2.Bounds) || button3.Bounds.IntersectsWith(button4.Bounds) || button3.Bounds.IntersectsWith(button7.Bounds))
            {
                x = broj.Next(0, 620);
                y = broj.Next(50, 420);
                button3.Left = x;
                button3.Top = y;
            }
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
